# runner-with-scrolling-bg
Simple 2D Phaser scene with a runner and scrolling background. All assets from opengameart.org
